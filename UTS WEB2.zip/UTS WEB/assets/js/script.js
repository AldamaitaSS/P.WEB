$(document).ready(function(){
    alert("Selamat datang, Silahkan input data member!");
});