$(document).ready(function(){
    alert("Selamat datang,\n\nSilahkan input data member!");
});