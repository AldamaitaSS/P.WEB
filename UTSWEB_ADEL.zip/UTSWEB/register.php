<!DOCTYPE html>
<html>

<head>
    <style>
        body,
        html {
            height: 100%;
            margin: 0;
        }

        body {
            background-image: url('asset/coffee_shop_with_warm_atmosphere___wallpaper_4k__-transformed.jpeg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 50%;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 5px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #5C3317;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 10px;
            text-align: left;
            width: 100%;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #5C3317;
        }

        .submit-button {
            background-color: #5C3317;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            font-weight: bold;
        }

        .submit-button:hover {
            background-color: #4C2812;
        }

        /* Style untuk tombol kembali */
        .back-button {
            background-color: #ccc;
            color: #000;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            font-weight: bold;
        }

        .back-button:hover {
            background-color: #999;
        }
    </style>
    <script src="jquery-3.7.1.js"></script>
</head>

<body>
    <div class="container">
        <h2>Be our Member</h2>
        <form action="registProses.php" method="post" id="registration-form">            <div class="form-group">
                <label for="fname">First Name:</label>
                <input type="text" id="fname" name="fname" required>
            </div>
            <div class="form-group">
                <label for="lname">Last Name:</label>
                <input type="text" id="lname" name="lname" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" class="submit-button" value="Register">
        </form>
    </div>

    <!-- JavaScript untuk menampilkan pesan berhasil registrasi -->
    <!-- <script>
        $(document).ready(function () {
            $('#registration-form').submit(function (event) {
                event.preventDefault(); // Mencegah formulir dikirim

                // Menampilkan pesan berhasil registrasi
                var successMessage = $('<div/>', {
                    text: 'Member successfully registered!',
                    css: {
                        color: 'green'
                    }
                });
                $(this).after(successMessage);

                // Redirect ke halaman utama setelah 2 detik
                setTimeout(function () {
                    window.location.href = 'index.html';
                }, 2000);
            });
        });
    </script> -->
</body>
</html>

